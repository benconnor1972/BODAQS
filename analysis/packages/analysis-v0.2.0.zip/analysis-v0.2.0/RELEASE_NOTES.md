# BODAQS Analysis v0.2.0

This release expands the BODAQS analysis package with a more configurable preprocessing workflow, broader configuration support, improved metadata and signal-semantics handling, bike-profile-aware processing, SynBike export support, and a more modular `bodaqs_analysis` Python API to support eventual use outside a notebook environment.

It includes the current analysis notebooks listed below, reusable `bodaqs_analysis` Python package, event schemas, default configuration files, bike-profile and log-metadata examples, session-note templates, and documentation.

## Highlights

- A complete re-work of how signal semantics are derived. Parsing column headers is gone - the pre-processing pipeline determines what signals mean either from a .json sidecar file accompanying the log (if it exists) or by reference to a generic log metadata library (if no sidecar is supplied). This change is supported by, but is not dependent on, firmware changes to capture signal semantics in the logger configuration and emit the sidecar files.
- More configurable preprocessing workflow, including reusable preprocess-profile support and clearer separation between persisted processing policy and notebook/runtime settings.
- Expanded analysis tooling and exports, including SynBike export support and additional lightweight suspension-analysis notebook workflows.
- Refactored `bodaqs_analysis` modules and notebooks to better separate analysis logic from notebook-specific presentation, supporting cleaner reuse across front ends.

Notebooks included are those with general end-user applicability:

- `bodaqs_batch_preprocessor.ipynb`
- `bodaqs_library_manager.ipynb`
- `bodaqs_data_explorer.ipynb`
- `bodaqs_session_browser.ipynb`
- `bodaqs_one_step_suspension_metrics.ipynb`
- `bodaqs_simple_suspension_metrics.ipynb`

The first four notebooks continue to cover the main artifact-based workflow; the next two provide lighter-weight suspension analysis entry points, including a one-step workflow and a simple metrics dashboard. The final notebook is for export from the library to syn.bike format.

## Notes on Package Contents

This release adds reusable configuration assets, including:
 - a baseline preprocess profile, `suspension_default_v1.json`
 - a generic bike profile, `example_enduro_bike_v1.json' intended to be duplicated and edited, and an actual bike profile for a 2021 Stumpjumper Evo
 - two generic log metadata files for the BODAQS logger: `current_logger_config_hr_timestamp_log_metadata.json` for logger configured to produce human-readable timestamps and `current_logger_config_fast_timestamp_log_metadata.json`for fast timestamps 
 - updated event schema and logger-to-analysis data interchange interchange documentation.

Generated local state and cache files are intentionally not included. This keeps the release clean, portable, and free of machine-specific or user-specific state.

Users should build or import their own processed artifact library from logger CSV files after unpacking the release. This should just mean copying your existing `artifacts` directory into `\analysis\` or creating a new directory.
