# BODAQS Public API Contract (v0)

**Status:** Stable (v0)  
**Audience:** Analysis notebooks, scripts, and future UI/CLI layers  
**Scope:** Public-facing analysis pipeline functions only

This document defines the **stable public API contract** for the BODAQS analysis pipeline.  
Anything not explicitly documented here is considered **internal** and may change without notice.

---

## 1. Purpose & Scope

The BODAQS public API provides a stable interface for:

- Loading logger CSV data into a canonical session structure
- Applying normalization, zeroing, and derived-signal transforms
- Detecting events from schema definitions
- Extracting metrics from detected events
- Running the full analysis pipeline via a single high-level preprocessing call

### Out of scope
- Internal helper functions
- Experimental utilities
- Visualization helpers
- Notebook-only convenience code

---

## 2. Core Concepts

### 2.1 Session

A **session** is a mutable dictionary that represents a single logging run and its analysis state.

At minimum, a valid session contains:

```python
session = {
    "df": pandas.DataFrame,   # canonical data table
    "meta": dict,             # optional metadata
    "qc": dict,               # optional quality-control / transform provenance
}
```

Detailed guarantees for the session structure are defined in  
**`BODAQS_Session_Schema_v0.md`**.

---

### 2.2 Canonical Time Axis

All public pipeline functions operate on a canonical time axis:

- **Column name:** `time_s`
- **Units:** seconds
- **Definition:** elapsed time from start of logging
- **Type:** float

**Guarantee:**  
Any public function that consumes a DataFrame assumes `time_s` exists.

Functions that load raw data (e.g. CSVs) must ensure `time_s` is created.

Absolute time anchoring is separate from the canonical `time_s` axis. When a
CSV filename or local time-of-day column needs a real-world timezone, the
precedence is:

1. `log_metadata.session.started_at_local`, if present
2. `log_metadata.session.timezone`, if present
3. the caller-supplied `timezone` fallback
4. the local machine timezone as a last resort, with QC warning

The caller-supplied `timezone` should be an IANA timezone such as
`"Australia/Perth"`. It is not the same as the run artifact timezone label such
as `"AWST"`.

---

## 3. Return & Diagnostics Conventions

### 3.1 Default Return Rule

> **Public functions return a single primary object by default.**

No public function returns a tuple unless explicitly requested.

---

### 3.2 Optional Diagnostics (`return_meta`)

Functions that can produce diagnostics, provenance, or algorithm details support:

```python
return_meta: bool = False
```

- `return_meta=False` (default): return the primary object only
- `return_meta=True`: return `(primary_object, meta_dict)`

The `meta_dict` is **machine-readable** and intended for:
- QC recording
- Provenance
- Debugging
- Reproducibility

---

### 3.3 Tuple Returns Are Forbidden by Default

Public API functions **must not** return tuples unless:
- `return_meta=True` is explicitly requested, and
- The tuple structure is documented here

Any tuple returned without opt-in is a contract violation.

---

## 4. Public Functions (v0)

### 4.0 High-Level API Shape

The public API now has two preferred high-level entry patterns:

- `preprocess_resolved(...)` for backend, service, and content-first workflows
- `preprocess_session(...)` for notebook/local convenience workflows

`preprocess_session(...)` accepts either:

- a logger CSV path, or
- an existing session dictionary

`preprocess_resolved(...)` accepts an already-built session plus already-resolved
schema/profile/FIT inputs. This is the preferred path for remote execution,
uploaded assets, and transport-agnostic orchestration layers.

Both entry points own the complete run-level pipeline:

```text
load/canonicalize -> zero -> bike transforms -> motion derivation/filtering
-> normalization -> activity masking -> event detection -> metric extraction
```

Event detection runs when an event schema is supplied and `include_events=True`.
Metric extraction runs when events are available and `include_metrics=True`.
The return value is always a results dictionary with stable top-level keys.

Lower-level functions such as `build_session_from_dataframe(...)`,
`prepare_logger_dataframe(...)`, `load_session(...)`,
`detect_events_from_schema(...)`, and `extract_metrics_df(...)` remain public for
advanced workflows, tests, and debugging. For new backend integrations, callers
should prefer these resolved-content helpers over path-first notebook
convenience wrappers.

The former notebook-era `run_macro(...)` entry point has been removed from the
active public API. Callers should use `preprocess_session(...)` or
`preprocess_resolved(...)` instead.

### 4.1 Preprocess Profile Helpers

**Purpose:**  
Load and validate persisted preprocessing configuration.

**Signatures:**
```python
config = default_preprocess_config(**overrides)
profile = make_preprocess_profile(profile_id: str, config=config, ...)
profile = load_preprocess_profile(path: str | Path)
config = load_preprocess_config(path: str | Path)
config = preprocess_config_from_profile(profile: Mapping[str, Any])
config = resolve_preprocess_config_paths(config, base_dir=path)
path = save_preprocess_profile(profile, path: str | Path)
records = discover_preprocess_profiles(directory: str | Path)
```

**Returns:**
- `default_preprocess_config(...)`: a validated default config payload
- `make_preprocess_profile(...)`: a validated full profile document
- `load_preprocess_profile(...)`: the full profile document
- `load_preprocess_config(...)`: the validated `profile["config"]` payload
- `resolve_preprocess_config_paths(...)`: a copy of the config with path-like fields resolved
- `save_preprocess_profile(...)`: the path written
- `discover_preprocess_profiles(...)`: lightweight profile records for menus/editors

**Guarantees:**
- No tuple returns
- Unexpected profile schema/version raises `ValueError`
- Missing required config fields raise `ValueError`
- New callers can pass the returned config directly to `preprocess_session(..., preprocess_config=config)`
- Scripts and notebook UIs can create/edit/save profiles without duplicating JSON-shaping logic
- Persisted preprocess profiles contain reusable processing policy only; run-specific bindings such as log metadata paths, bike profile paths, FIT directories, and FIT binding manifests are supplied separately by the caller.

---

### 4.2 Session & Logger Input Helpers

**Purpose:**  
Support both content-first and path-first session construction.

**Resolved-content signatures (conceptual):**
```python
log_metadata = parse_logger_log_metadata(log_metadata_obj_or_text_or_bytes_or_path)
df_prepared, log_metadata = prepare_logger_dataframe(
    df_raw,
    log_metadata=log_metadata,
)
session = build_session_from_dataframe(
    df_prepared,
    source_name="ride.csv",
    log_metadata=log_metadata,
)
```

**Path-convenience signature (conceptual):**
```python
session = load_session(
    csv_path: str,
    *,
    timezone: Optional[str] = None,
    log_metadata_path: Optional[str] = None,
    generic_log_metadata_paths: Optional[Sequence[str | Path]] = None,
)
```

**Returns:**  
- `parse_logger_log_metadata(...)`: parsed logger metadata object
- `prepare_logger_dataframe(...)`: `(DataFrame, log_metadata_or_none)`
- `build_session_from_dataframe(...)`: `session: Dict[str, Any]`
- `load_session(...)`: `session: Dict[str, Any]`

**Guarantees:**
- `prepare_logger_dataframe(...)` canonicalizes `time_s`
- `build_session_from_dataframe(...)` does not require a filesystem path
- `load_session(...)` is the notebook/local wrapper that performs CSV and metadata path resolution
- `session["df"]` is a pandas DataFrame
- `session["df"]` contains `time_s`
- Timestamp parsing is handled internally
- When logger log metadata is available, ingest may use it for delimiter, time-column, and metadata hints
- `timezone` is a fallback for filename/local-time anchoring only; log metadata timezone fields take precedence when present
- Generic log metadata paths are a run-level fallback and are not loaded from the preprocess profile.

---

### 4.3 Schema & Bike-Profile Parsing

**Purpose:**  
Allow callers to pass already-loaded schema/profile content directly.

**Signatures:**
```python
schema = parse_event_schema(schema_obj_or_text_or_bytes_or_path)
schema, meta = parse_event_schema(schema_obj_or_text_or_bytes_or_path, return_meta=True)

schema = load_event_schema(path: str)
schema, meta = load_event_schema(path: str, return_meta=True)

bike_profile = parse_bike_profile(profile_obj_or_text_or_bytes_or_path)
bike_profile = load_bike_profile(path: str | Path)
```

**Returns:**
- `parse_event_schema(...)` / `load_event_schema(...)`: schema dict, plus optional meta
- `parse_bike_profile(...)` / `load_bike_profile(...)`: bike profile dict

**Meta contents (minimum):**
- `sha256`: content hash
- `source_path`: schema file path when available, otherwise `None`

---

### 4.4 `normalize_and_scale()`

**Purpose:**  
Legacy convenience helper for applying optional zeroing and scaling to selected columns.

**Signature (conceptual):**
```python
df = normalize_and_scale(df, ranges, ...)
df, meta = normalize_and_scale(df, ranges, ..., return_meta=True)
```

**Behavior:**
- Returns a new DataFrame; the input frame is not modified.
- If zeroing is enabled, explicit `<col>_op_zeroed` physical columns are created.
- Normalized outputs are always created from the selected normalization source.
- If the normalization source is zeroed, output names encode both operations, for example `<col> [1]_op_zeroed_norm`.
- For full preprocessing runs, callers should prefer `preprocess_session()`, which applies zeroing before bike-profile transforms and normalization after bike-profile transforms.

**Returns:**
- Default: `DataFrame`
- With `return_meta=True`: `(DataFrame, meta)`

**Guarantees:**
- Output DataFrame preserves `time_s`
- Scaling is deterministic given inputs
- Meta describes zeroing and scaling truthfully

---

### 4.5 `estimate_va_from_zeroed()`

**Purpose:**  
Compute velocity and acceleration via Savitzky-Golay differentiation.

This is a lower-level compatibility helper. Standard preprocessing should use
the `motion_derivation` pipeline, which combines displacement filtering,
Savitzky-Golay differentiation, and post-derivative bandwidth filtering in one
provenance-recorded preprocessing step.

**Signature (conceptual):**
```python
df = estimate_va_from_zeroed(df, ...)
df, meta = estimate_va_from_zeroed(df, ..., return_meta=True)
```

**Returns:**
- Default: `DataFrame`
- With `return_meta=True`: `(DataFrame, meta)`

**Guarantees:**
- Adds `<col>_vel` and `<col>_acc`
- Does not modify existing base columns
- Uses `time_s` or inferred `dt`

---

### 4.6 High-Level Preprocessing

#### `preprocess_resolved()`

**Purpose:**  
Run the standard BODAQS preprocessing pipeline from already-resolved inputs.

**Signature (conceptual):**
```python
results = preprocess_resolved(
    session,
    *,
    schema=None,
    preprocess_profile=None,
    preprocess_config=None,
    fit_import=None,
    fit_stream=None,
    fit_candidates=None,
    fit_bindings=None,
    bike_profile=None,
    normalize_ranges=None,
    include_events=True,
    include_metrics=True,
    ...
)
```

**Typical use:**
```python
schema = parse_event_schema(schema_text)
bike_profile = parse_bike_profile(bike_profile_json)
df_prepared, log_metadata = prepare_logger_dataframe(df_raw, log_metadata=log_metadata_obj)
session = build_session_from_dataframe(df_prepared, source_name="ride.csv", log_metadata=log_metadata)

results = preprocess_resolved(
    session,
    schema=schema,
    preprocess_config=config,
    bike_profile=bike_profile,
    fit_candidates=fit_candidates,   # optional
    fit_bindings=fit_bindings,       # optional
)
```

**Guarantees:**
- No filesystem path is required
- `schema` must be supplied explicitly when events are enabled; `preprocess_resolved(...)`
  does not follow `schema_path` embedded inside `preprocess_config`
- `fit_stream`, `fit_candidates`, and `fit_bindings` allow remote/backend FIT import
  without `fit_dir` or `bindings_path`

#### `preprocess_session()`

**Purpose:**  
Run the standard BODAQS preprocessing pipeline for one session or CSV.

This remains the preferred notebook/local convenience wrapper. It accepts
path-based inputs such as `schema_path`, `log_metadata_path`,
`bike_profile_path`, and optional FIT directory/bindings settings via
`fit_import`.

**Signature:**
```python
results = preprocess_session(
    session_or_path,
    schema_path: Optional[str | Path] = None,
    *,
    preprocess_profile_path: Optional[str | Path] = None,
    preprocess_profile: Optional[Mapping[str, Any]] = None,
    preprocess_config: Optional[Mapping[str, Any]] = None,
    log_metadata_path: Optional[str | Path] = None,
    generic_log_metadata_paths: Optional[Sequence[str | Path]] = None,
    fit_import: Optional[Mapping[str, Any]] = None,
    normalize_ranges: Optional[Dict[str, float]] = None,
    bike_profile_path: Optional[str | Path] = None,
    bike_profile: Optional[Mapping[str, Any]] = None,
    sample_rate_hz: Optional[float] = None,
    prefer_postprocessing_transformations: bool = False,
    motion_derivation: Optional[Mapping[str, Any]] = None,
    butterworth_smoothing: Optional[list[dict[str, float | int]]] = None,
    butterworth_generate_residuals: bool = False,
    active_signal_disp_selector: Optional[Mapping[str, Any]] = None,
    active_signal_vel_selector: Optional[Mapping[str, Any]] = None,
    timezone: Optional[str] = None,
    include_events: bool = True,
    include_metrics: bool = True,
    ...
)
```

**Returns:**  
```python
{
    "session": session,
    "schema": schema,
    "events": events_df,
    "segments": bundles_by_schema_id,
    "metrics": metrics_df,
}
```

**Guarantees:**
- `results["session"]["df"]` remains a DataFrame
- `time_s` is preserved
- QC and transform provenance are recorded under `session["qc"]`
- New backend callers should prefer `preprocess_resolved(...)`; `preprocess_session(...)`
  remains the local/notebook compatibility surface
- New callers may pass a single `preprocess_config` payload instead of unpacking individual preprocessing fields.
- Normalization ranges may be supplied directly as a runtime `normalize_ranges` map, or resolved
  from a bike profile using semantic signal selectors.
- Persisted preprocess profiles select activity-mask signals by semantic selectors, not dataframe
  column names. Runtime column-name overrides remain available for scripts that need them.
- Persisted preprocess profiles may include a `motion_derivation` block describing
  analysis-channel filtering and VA derivation policy. When enabled, preprocessing
  generates primary/secondary filtered displacement, velocity, and acceleration
  channels before normalization and activity-mask resolution.
- `prefer_postprocessing_transformations=True` keeps logger-originated transformed
  signals in the dataframe but lets bike-profile transforms and motion derivation
  win when equivalent displacement semantics are available from analysis. When false,
  bike-profile transforms still run unless an equivalent logger-originated output
  signal already exists.
- `timezone` is passed through to session loading as a fallback logger timezone
  for filename/local-time anchoring. Same-stem log metadata remains authoritative
  when it declares `session.started_at_local` or `session.timezone`.
- Generated analysis channels may carry registry provenance such as `processing_role`,
  `motion_source_id`, `motion_profile_id`, and structured `derivation` metadata. Semantic
  selectors may use these fields to request a primary analysis channel explicitly.
- If zeroing is enabled, physical displacement columns are zeroed before bike-profile signal transforms are applied.
- Normalized `[1]` outputs are generated after bike-profile signal transforms have been applied.
- When motion derivation is enabled, generated displacement analysis channels are also
  normalized using the full range of their source displacement signal.
- When `butterworth_smoothing` is provided, additional append-only displacement variants are created
  using zero-phase SOS Butterworth filtering.
- When `butterworth_generate_residuals=True`, each generated Butterworth series also emits an
  append-only residual series named `<butterworth_series>_resid`.
- If no schema is supplied, or event detection is disabled, `schema` is `None` and `events`, `segments`, and `metrics` are empty containers.
- If a schema is supplied and `include_events=True`, event detection runs automatically.
- If events are available and `include_metrics=True`, segment extraction and metric calculation run automatically.
- When `fit_import` is enabled and a matching FIT file is resolved, the session may include
  resampled GPS columns on `session["df"]` and raw secondary stream data under `session["stream_dfs"]`.

Example notebook/local call pattern:

```python
config = load_preprocess_config("config/preprocess_profiles/suspension_default_v1.json")
fit_import = dict(config.get("fit_import") or {})
if fit_import.get("enabled"):
    fit_import["fit_dir"] = "Garmin/FIT"
    fit_import["bindings_path"] = "config/fit_bindings_v1.json"

results = preprocess_session(
    "ride.csv",
    preprocess_config=config,
    schema_path="event_schema/event_schema - Basic.yaml",
    generic_log_metadata_paths=["config/log_metadata_examples/current_logger_config_hr_timestamp_log_metadata.json"],
    bike_profile_path="config/bike_profiles/example_enduro_bike_v1.json",
    fit_import=fit_import,
)
```

Callers should prefer `preprocess_config` or `preprocess_profile_path` for reusable preprocessing policy in new workflows. Local/run-specific inputs such as log metadata selection, bike profile selection, FIT source directory, and FIT binding manifest are passed as explicit run-level arguments rather than persisted inside the preprocess profile.

---

### 4.7 External Format Exporters

#### data.syn.bike

**Purpose:**  
Export a processed BODAQS session to the headerless CSV shape expected by
data.syn.bike.

The core exporter follows the same resolved-content pattern as preprocessing:
it consumes an in-memory processed session and returns export tables plus
metadata. Writing those tables to local files is a separate convenience helper.

**Signatures:**
```python
config = default_data_syn_bike_export_config(**overrides)

result = export_data_syn_bike_resolved(
    session,
    export_config=config,
)

write_result = write_data_syn_bike_exports(
    result,
    output_dir,
    filename_template="{run_id}__{session_id}__{export_id}__data_syn_bike.csv",
)
```

**Returns:**
```python
{
    "format": "data_syn_bike",
    "session_id": "...",
    "run_id": "...",
    "config": {...},
    "exports": [
        {
            "export_id": "session" | "activity_001",
            "dataframe": pandas.DataFrame,
            "region": {
                "start_row": int,
                "end_row_exclusive": int,
                "start_time_s": float | None,
                "end_time_s": float | None,
            },
            "metadata": {...},
        }
    ],
    "summary": {...},
}
```

**Guarantees:**
- `export_data_syn_bike_resolved(...)` performs no filesystem IO.
- `write_data_syn_bike_exports(...)` writes headerless CSV files and returns the
  paths written.
- Front and rear raw channels are selected semantically, preferring wheel-domain
  raw signals over suspension-domain raw signals when both are present.
- Raw inversion is resolved independently for front and rear from signal/channel
  calibration metadata, declared sensor calibration metadata, and optional
  manual overrides.
- Missing latitude, longitude, or speed columns are exported as blank fields.
- `drop_inactive=True` omits rows marked inactive by `active_mask_qc`,
  `inactive_mask_qc`, or `inactive_mask`.
- `split_by_activity=True` emits one export table per contiguous active region.
  If no activity mask is present, the full session is treated as active.
- `time_format="sample_count"` emits unsigned-style sample counts. The
  `sample_count_origin` option controls whether those counts preserve source
  session row numbers or restart from zero for each emitted export.

---

### 4.8 FIT Helpers

**Purpose:**  
Support pathless FIT parsing, summary inspection, overlap resolution, and binding resolution.

**Signatures (conceptual):**
```python
summary = inspect_fit_stream(fit_input_or_path, field_allowlist=...)
df_fit, fit_meta = parse_fit_stream(fit_input_or_path, session_start_datetime=...)
bindings = parse_fit_bindings(bindings_obj_or_text_or_bytes_or_path)
candidates = find_overlapping_fit_candidates(
    summaries,
    session_start_datetime=...,
    session_end_datetime=...,
)
```

**Guarantees:**
- `inspect_fit_stream(...)` and `parse_fit_stream(...)` accept raw FIT bytes as well as paths
- `find_overlapping_fit_candidates(...)` does not require a directory scan
- `parse_fit_bindings(...)` accepts in-memory payloads as well as files
- `find_overlapping_fit_files(...)`, `load_fit_bindings(...)`, and `upsert_fit_binding(...)`
  remain public local/storage convenience wrappers

---

### 4.9 `detect_events_from_schema()`

**Purpose:**  
Detect events based on a schema definition.

**Signature (conceptual):**
```python
events_df = detect_events_from_schema(df, schema)
```

**Returns:**
- `events_df: DataFrame`

**Guarantees:**
- Events are indexed or timestamped in `time_s`
- Schema is treated as read-only

---

### 4.10 `extract_metrics_df()`

**Purpose:**  
Extract per-event metrics into a flat table.

**Signature:**
```python
metrics_df = extract_metrics_df(events_df)
```

**Returns:**
- `metrics_df: DataFrame`

---

## 5. Error & Validation Model

### 5.1 Validation Errors
- Bad user input → `ValueError`
- Invalid schema structure → `ValueError`

### 5.2 Internal Invariants
- Enforced via `assert`
- Indicate programmer error, not user error

### 5.3 Session Validation
- `validate_session()` enforces session invariants
- Called at public pipeline boundaries

---

## 6. Versioning & Stability

### v0 Guarantees
- Public function signatures documented here are stable
- Return types and invariants will not change silently

### May Change Without v1
- Meta dictionary contents may expand
- QC fields may gain additional detail

### Requires Version Bump
- Breaking signature changes
- Changing canonical column names
- Changing default return types

---

## 7. Design Principles (Non-Normative)

- Explicit over implicit
- No tuple surprises
- Provenance is opt-in but structured
- Canonical time everywhere

---

**End of v0 Public API Contract**
